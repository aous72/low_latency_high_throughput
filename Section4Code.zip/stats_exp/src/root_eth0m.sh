sudo ifconfig root-eth0 up
sudo ifconfig root-eth1 up
sudo ifconfig root-eth0 10.0.0.254 netmask 255.255.255.0
sudo ifconfig root-eth1 10.0.0.253 netmask 255.255.255.0

