sudo ifconfig root-eth0 up
sudo ifconfig root-eth0 10.0.0.254 netmask 255.255.255.0

