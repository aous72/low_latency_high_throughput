#!/bin/bash

# Exit on any failure
set -e

# Check for uninitialized variables
set -o nounset

ctrlc() {
	killall -9 python
	mn -c
	exit
}

trap ctrlc SIGINT

sudo python kduPox.py
sudo python simplemn.py
#     -l $max_level \
#     -n $servers \
