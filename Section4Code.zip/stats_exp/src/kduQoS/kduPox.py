from mininet.node import RemoteController
from mininet.node import Controller
from os import environ
from os import chdir
import subprocess


POXDIR = environ['HOME']+'/pox'

class kduPox(Controller):
    def __init__(self, 
                 name, 
                 cdir=POXDIR, 
                 command='python pox.py', 
                 cargs=('log --file=kdu.log,w openflow.of_01 --port=%s kduQosController'), 
                 **kwargs):
        Controller.__init__(self, name, cdir=cdir, command=command, cargs=cargs, **kwargs)


controllers={'pox':kduPox}
