rm s0-eth*
python tcshow.py --intf s1-eth2,s2-eth2 --iter 10 --ipblock '10.0.0.3/32' --portRange '5001-5002' --cToS True --linkCap '0.15'
