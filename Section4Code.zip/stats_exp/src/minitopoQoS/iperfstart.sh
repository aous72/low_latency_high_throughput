iperf -s -D -p 5001 -i 1 > iperf-recv-5001.txt &
iperf -s -D -p 5002 -i 1 > iperf-recv-5002.txt &