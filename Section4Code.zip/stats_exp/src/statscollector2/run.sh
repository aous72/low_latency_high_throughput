sudo python statscollector.py

